# script.sh file
ulimit -n 1000000
while :
do
./eserver
sleep 1
done
